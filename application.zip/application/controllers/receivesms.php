<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class receivesms extends CI_Controller {


    function __construct() {
        parent::__construct();
              
      //session, url, satabase is set in auto load in the config
        $this->load->model('Receivesms_model', 'recive');
    }

    function index(){

    }


    function  receive(){
        $post_data['from']       =  $this->input->post('From');
        $post_data['body']       =  $this->input->post('Body');

        if($post_data['from'] && $post_data['body']){
            $this->receive->insert_received_message($post_data);
        }

    }



}
?>