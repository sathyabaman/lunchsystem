<?php

class Receivesms_model extends CI_Model {

	
    function __construct()
    {
    	parent::__construct();
    }

  
 

    function insert_received_message($data){

    	 $sms['pone_number']    = $data['from'];
         $sms['message_type']   = 2;
         $sms['body']           = $data['body'];
       
         $results = $this->db->insert('Sms_message', $sms); 
         return $results;
    }

   



}

?>