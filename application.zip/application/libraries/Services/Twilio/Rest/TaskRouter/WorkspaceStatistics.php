<?php

class Services_Twilio_Rest_TaskRouter_WorkspaceStatistics extends Services_Twilio_TaskRouterInstanceResource
{

}
